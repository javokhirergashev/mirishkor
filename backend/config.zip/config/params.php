<?php
return [
    'adminEmail' => 'admin@example.com',
    'languages' => [
        'uz' => 'O\'zbekcha',
        'en' => 'English',
        'ru' => 'Русский',
    ],
    'language' => [
        'uz' => 'O\'z',
        'en' => 'En',
        'ru' => 'Ру',
    ],
];
